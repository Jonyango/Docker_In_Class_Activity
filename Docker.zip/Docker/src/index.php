<?php
echo "Docker Inclass Activity "; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Book  Store</title>
</head>
<body>
<h1>A Simple Bookstore Application</h1>

    <form>
        <label for="title">Title:</label><br>
        <input type='text' id="title" name="Title"/><br>

        <label for="author">Author:</label><br>
        <input type='text' id="author" name="Author"/><br>

        <label for="quantity">Quantity:</label><br>
        <input type='text' id="quantity" name="Quantity"/><br><br>

</form>
<button onClick="getAddedData()">Add</button>

<div id ='viewStore'>
</body>

<script type='text/javascript'> 

function getAddedData()
{
    // retrieve the different elements of the bookstore
const Title = document.getElementById('title');
const Author = document.getElementById('author');
const Quantity = document.getElementById('quantity');


   //create elements of the elements
   let newTitle = document.createElement('P');
   let newAuthor = document.createElement('P');
   let newQuantity = document.createElement('P');

   //creating their corresponding textNode

     let title=document.createTextNode("Title :"+Title.value);
     let author=document.createTextNode("Author :" + Author.value);
     let quantity=document.createTextNode("Quantity : " + Quantity.value);

     //appending to the paragraph elements
     newTitle.appendChild(title);
     newAuthor.appendChild(author);
     newQuantity.appendChild(quantity);

//      //Array containing the data

//   let bookDetails = new Array();
//   bookDetails.push(["Title","Author","Quantity"]);
//   bookDetails.push([newTitle,newAuthor,newQuantity]);

//   //creates a table element
//   let table = document.createElement("TABLE");
//   table.border = "1";

//   //Get the count of columns.
//   let columnCount = bookDetails[0].length;

//   //Add the header row.
//   let row = table.insertRow(-1);
//         for (var i = 0; i < columnCount; i++) {
//             var headerCell = document.createElement("TH");
//             headerCell.innerHTML = bookDetails[0][i];
//             row.appendChild(headerCell);
//         }
 
//         //Add the data rows.
//         for (var i = 1; i < bookDetails.length; i++) {
//             row = table.insertRow(-1);
//             for (var j = 0; j < columnCount; j++) {
//                 var cell = row.insertCell(-1);
//                 cell.innerHTML = bookDetails[i][j];
//             }
//         }
 
//         var dvTable = document.getElementById("viewStore");
//         dvTable.innerHTML = "";
//         dvTable.appendChild(table);
//         document.body.appendChild(dvTable);

  let addedTitle = document.getElementById("viewStore").appendChild(newTitle);
  let addedAuthor = document.getElementById("viewStore").appendChild(newAuthor);
  let addedQuantity = document.getElementById("viewStore").appendChild(newQuantity);

  document.body.appendChild(addedTitle);
  document.body.appendChild(addedAuthor);
  document.body.appendChild(addedQuantity);

  

}
</script>

</html>

